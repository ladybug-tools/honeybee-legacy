# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class ConnectVRFsToGroundLoop < OpenStudio::Ruleset::WorkspaceUserScript

  # human readable name
  def name
    return "Connect VRFs to Ground Loop"
  end

  # human readable description
  def description
    return "This is an EnergyPus measure that is meant to follow the 'Ground Source with VRFs' measure and will connect the VRFs to the 'VRF Placeholder' objects on the ground loop."
  end

  # human readable description of modeling approach
  def modeler_description
    return "This is an EnergyPus measure that is meant to follow the 'Ground Source with VRFs' measure and will connect the VRFs to the 'VRF Placeholder' objects on the ground loop."
  end

  # define the arguments that the user will input
  def arguments(workspace)
    args = OpenStudio::Ruleset::OSArgumentVector.new

    return args
  end

  # define what happens when the measure is run
  def run(workspace, runner, user_arguments)
    super(workspace, runner, user_arguments)

    # get all VRF systems and ground loop branches in the starting model
    vrfs = workspace.getObjectsByType("AirConditioner:VariableRefrigerantFlow".to_IddObjectType)
    adiabaticPipes = workspace.getObjectsByType("Pipe:Adiabatic".to_IddObjectType)
    branches = workspace.getObjectsByType("Branch".to_IddObjectType)

    # reporting initial condition of model
    runner.registerInitialCondition("The building started with #{vrfs.size} VRF systems.")

    # Collect the names of all the VRFs.
    vrfNames = []
    vrfs.each do |vrf|
      vrfNames << vrf.getString(0).to_s
      vrf.setString(55,"WaterCooled")
    end

    # collect all of the VRF placeholders and make a list of input/output nodes.
    groundInletNodes = []
    groundOutletNodes = []
    vrfCount = 0
    branches.each do |branch|
      vrfStr = branch.getString(3).to_s
      if vrfStr.include? "VRF PLACEHOLDER"
        groundInletNodes << branch.getString(4).to_s
        groundOutletNodes << branch.getString(5).to_s
        branch.setString(2,"AirConditioner:VariableRefrigerantFlow")
        branch.setString(3,vrfNames[vrfCount])
        vrfCount = vrfCount + 1
      end
    end

    # Set the vrfs to be connected to the ground branches.
    vrfCount = 0
    vrfs.each do |vrf|
      vrf.setString(56,groundInletNodes[vrfCount])
      vrf.setString(57,groundOutletNodes[vrfCount])
      vrfCount = vrfCount + 1
    end
	
	# Remove the adiabatic pipes from the model.
	adiabaticPipeNames = []
	adiabaticPipes.each do |pipe|
	  pipeName = pipe.getString(0).to_s
	  if pipeName.include? "VRF PLACEHOLDER"
	    workspace.removeObject(pipe.handle)
		adiabaticPipeNames << pipeName
	  end
    end
	
    # report final condition of model
	finalString = "\nThe building finished with #{adiabaticPipeNames.size} adiabatic pipe placeholders that were removed from the model.\n"
    finishing_vrfs = workspace.getObjectsByType("AirConditioner:VariableRefrigerantFlow".to_IddObjectType)
	finalString = finalString + "The building finished with #{finishing_vrfs.size} VRF systems that are now connected to the ground loop."
    runner.registerFinalCondition(finalString)

    return true

  end

end

# register the measure to be used by the application
ConnectVRFsToGroundLoop.new.registerWithApplication
