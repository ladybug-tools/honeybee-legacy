# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class HoneybeeOutput < OpenStudio::Ruleset::WorkspaceUserScript

  # human readable name
  def name
    return "Honeybee Output"
  end

  # human readable description
  def description
    return "This is an EnergyPus measure that requests outputs for Honeybee."
  end

  # human readable description of modeling approach
  def modeler_description
    return "This is an EnergyPus measure that requests outputs for Honeybee."
  end

  # define the arguments that the user will input
  def arguments(workspace)
    args = OpenStudio::Ruleset::OSArgumentVector.new

    return args
  end

  # define what happens when the measure is run
  def run(workspace, runner, user_arguments)
    super(workspace, runner, user_arguments)

	# Edit the current output style object.
	tableStyleObjects = workspace.getObjectsByType("OutputControl:Table:Style".to_IddObjectType)
	tableStyleObjects.each do |tableStyle|
		tableStyle.setString(0, "CommaAndHTML")
		tableStyle.setString(1, "JtoKWH")
	end
	
	
	# Add the surfaces list.
	srfList = OpenStudio::IdfObject.new("Output:Surfaces:List".to_IddObjectType)
	srfList.setString(0, "Details")
	workspace.addObject(srfList)
	
	
    # report final condition of model
    runner.registerFinalCondition("Output to CSV has been successfully requested.")

    return true

  end

end

# register the measure to be used by the application
HoneybeeOutput.new.registerWithApplication
