# see the URL below for information on how to write OpenStudio measures
# http://nrel.github.io/OpenStudio-user-documentation/reference/measure_writing_guide/

# start the measure
class NaturalVentilation < OpenStudio::Ruleset::WorkspaceUserScript

  # human readable name
  def name
    return "Natural Ventilation"
  end

  # human readable description
  def description
    return "This is an EnergyPus measure that adds natural ventilation objects to an OpenStudio model using data within a CSV.  Such CSVs are output by Honeybee."
  end

  # human readable description of modeling approach
  def modeler_description
    return "This is an EnergyPus measure that adds natural ventilation objects to an OpenStudio model using data within a CSV.  Such CSVs are output by Honeybee."
  end

  # define the arguments that the user will input
  def arguments(workspace)
    args = []
	
    natVentCSV = OpenStudio::Ruleset::OSArgument.makeStringArgument("natVentCSV", true)
    natVentCSV.setDisplayName("Natural Ventilation CSV")
    natVentCSV.setDescription("File path to a CSV that contains all of the information needed to create simple natural ventilation objects for the OpenStudio model.  This CSV is typically output from the Honeybee OpenStudio exporter.")
    args << natVentCSV

    return args
  end

  # define what happens when the measure is run
  def run(workspace, runner, user_arguments)
    super(workspace, runner, user_arguments)
	
	# Read in the csv file with all of the inputs.
	natVentCSV = runner.getStringArgumentValue("natVentCSV", user_arguments)
	arrOfArrs = CSV.read(natVentCSV)

	# Create a string for each of the natural ventilation objects.
	stringObjects = []
	firstLine = true
	arrOfArrs.each do |obj|
		if firstLine == true
			firstLine = false
		else if obj[1] == 3
			stringObjects << "
			  ZoneVentilation:DesignFlowRate,
				#{obj[2]},    						  !- Name
				#{obj[0]},                            !- Zone Name
				#{obj[9]},            				  !- Nat Vent Schedule
				Flow/Zone,							  !- Design Flow Rate Calculation Method
				#{obj[8]},                            !- Design flow rate m3/s
				Flow/Zone,							  !- Design Flow Rate Calculation Method
				,									  !- Design flow rate per floor area
				,									  !- Flow Rate per person
				,									  !- Air chancges per hour
				Intake,								  !- Ventilation Type
				#{obj[11]},                           !- Fan Pressure Rise (Pa)
				#{obj[10]},             			  !- Fan Efficiency (Pa)
				1,             			  			  !- Constant Term Coefficient
				0,              			  		  !- Temperature Term Coefficient
				0,                       			  !- Velocity Term Coefficient
				0,              			  		  !- Velocity Squared Term Coefficient
				#{obj[3]},              			  !- Minimum Indoor Temperature
				,                       			  !- Minimum Indoor Temperature Schedule Name
				#{obj[4]},              			  !- Maximum Indoor Temperature
				,                       			  !- Maximum Indoor Temperature Schedule Name
				#{obj[5]},              			  !- Delta Temperature
				,                       			  !- Delta Temperature Schedule Name
				#{obj[6]},              			  !- Minimum Outdoor Temperature
				,                       			  !- Minimum Outdoor Temperature Schedule Name
				#{obj[7]},              			  !- Maximum Outdoor Temperature
				,                       			  !- Maximum Outdoor Temperature Schedule Name
				40;                       			  !- Maximum Wind Speed
				"
		else
			stringObjects << "
			  ZoneVentilation:WindandStackOpenArea,
				#{obj[2]},    						  !- Name
				#{obj[0]},                            !- Zone Name
				#{obj[8]},                            !- Opening Area
				#{obj[9]},            				  !- Nat Vent Schedule
				#{obj[10]},                           !- Opening Effectiveness
				#{obj[11]},                           !- Effective Angle
				#{obj[12]},             			  !- Height Difference
				#{obj[13]},             			  !- Discharge Coefficient for Opening
				#{obj[3]},              			  !- Minimum Indoor Temperature
				,                       			  !- Minimum Indoor Temperature Schedule Name
				#{obj[4]},              			  !- Maximum Indoor Temperature
				,                       			  !- Maximum Indoor Temperature Schedule Name
				#{obj[5]},              			  !- Delta Temperature
				,                       			  !- Delta Temperature Schedule Name
				#{obj[6]},              			  !- Minimum Outdoor Temperature
				,                       			  !- Minimum Outdoor Temperature Schedule Name
				#{obj[7]},              			  !- Maximum Outdoor Temperature
				,                       			  !- Maximum Outdoor Temperature Schedule Name
				40;                       			  !- Maximum Wind Speed
				"
			end
		end
	end
	
	
	
	# Add the natural ventilation objects to the file.
	stringObjects.each do |stringObject|
		idfObject = OpenStudio::IdfObject::load(stringObject)
		object = idfObject.get
		wsObject = workspace.addObject(object)
	end
	
	
    # report final condition of model
    runner.registerFinalCondition("Natural ventilation objects have been successfully added to the model.")

    return true

  end

end

# register the measure to be used by the application
NaturalVentilation.new.registerWithApplication
